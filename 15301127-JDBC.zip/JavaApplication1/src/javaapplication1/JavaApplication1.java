/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;

/**
 *
 * @author ltb
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // create a new connection from MySQLJDBCUtil
        try (Connection conn = MySQLJDBCUtil.getConnection()) {
            
            // print out a message
            System.out.println(String.format("Connected to database %s "
                    + "successfully.", conn.getCatalog()));
                  
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
    //
    //query
    //public static void main(String[] args) {
        // create a new connection from MySQLJDBCUtil
    //   QueryingData q = new QueryingData();
    //   q.query();
    //}
    
    //update
    //public static void main(String[] args) {
        // create a new connection from MySQLJDBCUtil
    //   UpdateData u = new UpdateData();
    //   u.update();
    //}
    
    //insert
    //public static void main(String[] args) {
        // create a new connection from MySQLJDBCUtil
    //   InsertData i = new InsertData();      
    //   int id = i.insertCandidate("Bush", "Lily",Date.valueOf( "1980-01-04"), 
    //                    "bush.l@yahoo.com", "(408) 898-6666");
    //    System.out.println(String.format("A new candidate with id %d has been inserted.",id));
    //}

    //transaction
    //public static void main(String[] args) {
        // create a new connection from MySQLJDBCUtil
    //    Candidate c = new Candidate();
    //   int[] skills = {1,2,3};
    //    c.addCandidate("John", "Doe", Date.valueOf("1990-01-04"), 
    //                    "john.d@yahoo.com", "(408) 898-5641", skills);
    //}

    //call MySQL stored procedures
    //public static void main(String[] args) {
        // create a new connection from MySQLJDBCUtil
    //    Skill s = new Skill();
    //    s.getSkills(122);
    //}
    
    //write and readg MySQL blob
    //public static void main(String[] args) {
        // create a new connection from MySQLJDBCUtil
    //    Blob b = new Blob();
    //    b.writeBlob(122, "johndoe_resume.pdf");
    //    b.readBlob(122, "johndoe_resume_from_db.pdf");
    //}
    
}

